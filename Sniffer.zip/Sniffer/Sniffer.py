import streamlit as st
import pandas as pd
import threading
import time
import queue # Import the queue module
from scapy.all import sniff, IP, TCP, UDP, conf # Import conf to get interface info if needed

# --- Packet Sniffer Logic ---

# Use st.session_state for thread-safe data storage across Streamlit reruns
# Initialize packet_data in session_state if it doesn't exist
if 'packet_data' not in st.session_state:
    st.session_state.packet_data = []

# The packet_queue will now be created and passed directly to the sniffing thread
# It does NOT need to be in st.session_state itself, but its *instance* will be managed by the main thread.

# This function will be defined inside run_sniffer's scope to capture the 'packet_q'
# def process_packet(packet):
#     """
#     Processes each captured packet and puts its data into the thread-safe queue.
#     """
#     # This function will now receive 'packet_q' as an argument or via closure
#     packet_info = {}
#     if packet.haslayer(IP):
#         ip_layer = packet.getlayer(IP)
#         packet_info['Source IP'] = ip_layer.src
#         packet_info['Destination IP'] = ip_layer.dst
#         packet_info['Protocol'] = "Other" # Default protocol

#         if packet.haslayer(TCP):
#             tcp_layer = packet.getlayer(TCP)
#             packet_info['Protocol'] = "TCP"
#             packet_info['Source Port'] = tcp_layer.sport
#             packet_info['Destination Port'] = tcp_layer.dport
#         elif packet.haslayer(UDP):
#             udp_layer = packet.getlayer(UDP)
#             packet_info['Protocol'] = "UDP"
#             packet_info['Source Port'] = udp_layer.sport
#             packet_info['Destination Port'] = udp_layer.dport
#         else:
#             # For other IP protocols like ICMP, IGMP etc.
#             packet_info['Protocol'] = ip_layer.proto # Get numerical protocol
#             packet_info['Source Port'] = 'N/A'
#             packet_info['Destination Port'] = 'N/A'
        
#         # Add a timestamp for better visualization/analysis
#         packet_info['Timestamp'] = time.strftime("%H:%M:%S")

#         # Put the packet info into the queue
#         packet_q.put(packet_info) # Use the queue instance passed to run_sniffer
#         # print(f"DEBUG: Packet captured and put in queue: {packet.summary()}") # Keep this for debugging in terminal
#     else:
#         # Handle non-IP packets (e.g., ARP, Ethernet frames) if desired
#         # print(f"DEBUG: Non-IP packet captured: {packet.summary()}")
#         pass


def run_sniffer(stop_event, iface_name, packet_q): # packet_q is now passed as an argument
    """
    Runs the Scapy sniffer in a separate thread.
    The 'stop_filter' will halt sniffing when the stop_event is set.
    """
    def process_packet_local(packet): # Define process_packet locally to access packet_q
        packet_info = {}
        if packet.haslayer(IP):
            ip_layer = packet.getlayer(IP)
            packet_info['Source IP'] = ip_layer.src
            packet_info['Destination IP'] = ip_layer.dst
            packet_info['Protocol'] = "Other" # Default protocol

            if packet.haslayer(TCP):
                tcp_layer = packet.getlayer(TCP)
                packet_info['Protocol'] = "TCP"
                packet_info['Source Port'] = tcp_layer.sport
                packet_info['Destination Port'] = tcp_layer.dport
            elif packet.haslayer(UDP):
                udp_layer = packet.getlayer(UDP)
                packet_info['Protocol'] = "UDP"
                packet_info['Source Port'] = udp_layer.sport
                packet_info['Destination Port'] = udp_layer.dport
            else:
                packet_info['Protocol'] = ip_layer.proto
                packet_info['Source Port'] = 'N/A'
                packet_info['Destination Port'] = 'N/A'
            
            packet_info['Timestamp'] = time.strftime("%H:%M:%S")
            packet_q.put(packet_info) # Use the passed packet_q
        
    try:
        # print(f"DEBUG: Sniffer thread started on interface: {iface_name}") # Debug print
        sniff(prn=process_packet_local, iface=iface_name, stop_filter=lambda p: stop_event.is_set(), store=0)
        # print("DEBUG: Sniffer thread stopped.")
    except Exception as e:
        print(f"ERROR: Sniffer thread encountered an error: {e}")

# --- Streamlit Dashboard UI ---

st.set_page_config(page_title="Packet Sniffer Dashboard", layout="wide")
st.title("📊 Real-Time Network Traffic Dashboard")

# Initialize session state variables if they don't exist
if 'sniffing' not in st.session_state:
    st.session_state.sniffing = False
    st.session_state.thread = None
    st.session_state.stop_event = None
    # Initialize the queue here, it's a regular Python object
    st.session_state.packet_queue_instance = queue.Queue()


# Get available interfaces dynamically (optional, but good practice)
# This will use the human-readable names
available_interfaces = [iface.name for iface in conf.ifaces.values()]
if not available_interfaces:
    st.error("No network interfaces found. Please ensure Npcap (Windows) or libpcap (Linux/macOS) is installed and Scapy can detect interfaces.")
    st.stop() # Stop the app if no interfaces are found

# Interface selection dropdown
selected_interface = st.selectbox(
    "Select Network Interface:",
    options=available_interfaces,
    index=available_interfaces.index("WiFi") if "WiFi" in available_interfaces else 0 # Default to WiFi if available
)

# Start/Stop buttons
col1, col2 = st.columns(2)
with col1:
    if st.button('Start Sniffing', disabled=st.session_state.sniffing):
        st.session_state.packet_data.clear()  # Clear previous data on start
        # Clear the queue as well
        while not st.session_state.packet_queue_instance.empty(): # Use the instance
            st.session_state.packet_queue_instance.get_nowait()

        st.session_state.sniffing = True
        st.session_state.stop_event = threading.Event()
        # Pass the queue instance to the thread
        st.session_state.thread = threading.Thread(target=run_sniffer, args=(st.session_state.stop_event, selected_interface, st.session_state.packet_queue_instance))
        st.session_state.thread.daemon = True # Allow main program to exit even if thread is running
        st.session_state.thread.start()
        # No st.rerun() here, as the state change will trigger a rerun anyway

with col2:
    if st.button('Stop Sniffing', disabled=not st.session_state.sniffing):
        if st.session_state.stop_event:
            st.session_state.stop_event.set()
            # Give thread a moment to stop, but avoid blocking UI too long
            # st.session_state.thread.join(timeout=1)
        st.session_state.sniffing = False
        # No st.rerun() here, as the state change will trigger a rerun anyway

# --- Dashboard Display ---

# Use a placeholder to update the status message
status_placeholder = st.empty()
if st.session_state.sniffing:
    status_placeholder.success("Sniffer is running... Capturing packets on " + selected_interface)
else:
    status_placeholder.info("Sniffer is stopped. Click 'Start Sniffing' to begin.")

# Create placeholders for dynamic content
protocol_chart_placeholder = st.empty()
data_frame_placeholder = st.empty()

# This loop will run continuously while the app is active,
# updating the display based on the packet_data in session_state.
# It does NOT use st.rerun(), relying on Streamlit's natural flow.
while True:
    # Safely get packets from the queue and append to st.session_state.packet_data
    # Use the instance of the queue stored in session_state
    while not st.session_state.packet_queue_instance.empty():
        packet = st.session_state.packet_queue_instance.get_nowait()
        st.session_state.packet_data.append(packet)

    if st.session_state.packet_data:
        df = pd.DataFrame(st.session_state.packet_data)
        
        with protocol_chart_placeholder.container():
            st.header("Protocol Distribution")
            # Ensure 'Protocol' column exists before value_counts
            if 'Protocol' in df.columns:
                protocol_counts = df['Protocol'].value_counts()
                st.bar_chart(protocol_counts)
            else:
                st.write("Waiting for protocol data...")

        with data_frame_placeholder.container():
            st.header("Captured Packets")
            # Display last 50 packets, sorted by timestamp (if you add it)
            if 'Timestamp' in df.columns:
                st.dataframe(df.tail(50).sort_values(by='Timestamp', ascending=False), use_container_width=True)
            else:
                st.dataframe(df.tail(50), use_container_width=True)
            
    # Only sleep if sniffing is active to avoid constant redraws when stopped
    if st.session_state.sniffing:
        time.sleep(1) # Refresh interval for the UI
    else:
        # If sniffing is stopped and no more packets, break the display loop
        # Or, if you want to keep showing the last captured data, just remove the break
        if not st.session_state.packet_data and st.session_state.packet_queue_instance.empty():
            break # Exit the display loop if no sniffing, no data, and no pending packets
        time.sleep(1) # Still sleep to prevent busy-waiting if data is present but sniffing stopped
